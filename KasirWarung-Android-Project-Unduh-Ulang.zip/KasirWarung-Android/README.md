# Kasir Warung Android — project awal v1.0

Project Android native Kotlin + Jetpack Compose. Data awal di `app/src/main/assets/products_seed.csv` diekspor dari file Excel yang diberikan (874 baris produk).

## Buka project
1. Instal Android Studio versi terbaru dan Android SDK 35.
2. Buka folder `KasirWarung-Android`.
3. Tunggu Gradle Sync selesai.
4. Jalankan pada emulator/perangkat Android (minSdk 26).

## Status implementasi saat paket ini dibuat
- [x] Struktur project Kotlin + Compose.
- [x] Database Room untuk produk dan transaksi (entitas/DAO dasar).
- [x] Tampilan awal tab Kasir, Barang, Laporan, Pengaturan.
- [x] Data produk 874 item tersedia sebagai CSV seed.
- [ ] Import CSV otomatis ke Room saat instalasi pertama.
- [ ] Alur checkout final, validasi stok, dan penyimpanan detail item transaksi.
- [ ] Login aman (hash password dan manajemen sesi).
- [ ] Scan kamera CameraX + ML Kit.
- [ ] Bluetooth ESC/POS 58 mm (pairing, permission, koneksi, cetak).
- [ ] WorkManager + endpoint Google Apps Script dengan idempotency key.
- [ ] Backup/pemulihan dan uji multi-perangkat.

**Penting:** Ini adalah project sumber awal, bukan APK siap instal dan belum boleh dipakai untuk transaksi toko. Sinkronisasi Google Sheets memerlukan URL deployment Apps Script milik pemilik. Password admin tidak ditanam di source code. Jangan gunakan kredensial contoh; buat password saat setup pertama setelah modul autentikasi selesai.

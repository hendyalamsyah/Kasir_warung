package id.warung.kasir

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.launch
import java.util.UUID

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val sourceId: Long? = null,
    val name: String,
    val barcode: String? = null,
    val unit: String = "PCS",
    val cost: Long = 0,
    val price: Long = 0,
    val p025: Long = 0,
    val p05: Long = 0,
    val p075: Long = 0,
    val stock: Double = 0.0
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val createdAt: Long = System.currentTimeMillis(),
    val total: Long,
    val paid: Long,
    val changeAmount: Long,
    val syncState: String = "PENDING"
)

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name")
    suspend fun all(): List<Product>
    @Query("SELECT * FROM products WHERE name LIKE '%' || :q || '%' OR barcode = :q ORDER BY name")
    suspend fun search(q: String): List<Product>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<Product>)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(item: Product)
}

@Dao
interface SaleDao {
    @Insert
    suspend fun save(sale: Sale)
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    suspend fun all(): List<Sale>
    @Query("SELECT * FROM sales WHERE syncState = 'PENDING'")
    suspend fun pending(): List<Sale>
}

@Database(entities = [Product::class, Sale::class], version = 1, exportSchema = true)
abstract class WarungDb : RoomDatabase() {
    abstract fun products(): ProductDao
    abstract fun sales(): SaleDao
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, WarungDb::class.java, "kasir-warung.db").build()
        setContent { KasirWarungApp(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KasirWarungApp(db: WarungDb) {
    var tab by remember { mutableStateOf("Kasir") }
    var query by remember { mutableStateOf("") }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var cart by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    val scope = rememberCoroutineScope()
    val money = { n: Long -> "Rp " + "%,d".format(n).replace(',', '.') }

    LaunchedEffect(Unit) { products = db.products().all() }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF16845B))) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Kasir Warung") }) },
            bottomBar = {
                NavigationBar {
                    listOf("Kasir", "Barang", "Laporan", "Pengaturan").forEach {
                        NavigationBarItem(selected = tab == it, onClick = { tab = it },
                            icon = {}, label = { Text(it) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                when (tab) {
                    "Kasir", "Barang" -> {
                        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(),
                            label = { Text("Cari nama barang / barcode") }, singleLine = true)
                        Button(onClick = {
                            scope.launch {
                                products = if (query.isBlank()) db.products().all() else db.products().search(query)
                            }
                        }, modifier = Modifier.padding(vertical = 8.dp)) { Text("Cari barang") }
                        if (tab == "Kasir") {
                            Text("Keranjang: ${cart.values.sum()} item")
                            Text("Total: " + money(products.filter { cart.containsKey(it.id) }
                                .sumOf { it.price * (cart[it.id] ?: 0) }))
                        }
                        LazyColumn {
                            items(products, key = { it.id }) { p ->
                                ListItem(
                                    headlineContent = { Text(p.name) },
                                    supportingContent = { Text("${p.unit} • Stok ${p.stock} • ${money(p.price)}") },
                                    trailingContent = {
                                        if (tab == "Kasir") {
                                            Button(onClick = { cart = cart + (p.id to ((cart[p.id] ?: 0) + 1)) }) { Text("+") }
                                        } else Text("HPP ${money(p.cost)}")
                                    }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                    "Laporan" -> Text("Laporan penjualan akan tampil setelah modul transaksi diaktifkan.")
                    else -> Text("Pengaturan: printer Bluetooth 58 mm dan Google Sheets disiapkan pada tahap integrasi.")
                }
            }
        }
    }
}
